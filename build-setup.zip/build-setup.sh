#!/bin/bash
set -e
# =======================================================
#               SCRIPT: Opendreambox Build Setup
# =======================================================
# ======= USER SETTINGS =======
KEY="$HOME/.ssh/id_ed25519"  # <--- ADJUSTED: Using your existing key
REPO_ALIAS="github-opendreambox:WXbet/opendreambox.git"
DIR="$HOME/opendreambox"
# =============================
# Machine Map -> Target Branch
set -e
KEY="$HOME/.ssh/id_ed25519"
REPO_ALIAS="github-opendreambox:WXbet/opendreambox.git"
DIR="$HOME/opendreambox"
declare -A MACHINE_BRANCH=(
[dm520]=krogoth
[dm820]=krogoth
[dm7080]=krogoth
[dm900]=krogoth
[dm920]=krogoth
[dreamone]=pyro
[dreamtwo]=pyro
)
err() {
if command -v whiptail >/dev/null; then
whiptail --title "❌ Setup Error" --msgbox "$*" 10 90
fi
echo "❌ $*" >&2
exit 1
}
if ! command -v whiptail >/dev/null; then
echo "==> Installing whiptail (required for GUI)..."
sudo apt-get update
sudo apt-get install -y whiptail || { echo "❌ Failed to install whiptail. Please install manually." >&2; exit 1; }
fi
whiptail --title "Starting Setup Script" --msgbox "==> Starting Setup: SSH + GitHub + Opendreambox Image Build and Feed Configuration" 10 90

# ----------------------------------------------------------------------
# START: الكود الموحد لاستبدال رسائل SSH الثلاثة السابقة
# ----------------------------------------------------------------------

# 1. إنشاء المفتاح الفعلي (دون عرض رسالة whiptail)
KEY_ACTION="⚠️ Key already exists: $KEY. The existing key will be used."
if [ ! -f "$KEY" ]; then
    mkdir -p "$(dirname "$KEY")"
    chmod 700 "$(dirname "$KEY")"
    ssh-keygen -t ed25519 -f "$KEY" -N ""
    KEY_ACTION="✅ Created new SSH key: $KEY"
fi

# 2. إعداد ملف SSH Config (دون عرض رسالة whiptail)
SSHCONF="$HOME/.ssh/config"
if ! grep -q "Host github-opendreambox" "$SSHCONF" 2>/dev/null; then
    {
        echo ""
        echo "Host github-opendreambox"
        echo "    HostName github.com"
        echo "    User git"
        echo "    IdentityFile $KEY"
        echo "    IdentitiesOnly yes"
    } >> "$SSHCONF"
    chmod 600 "$SSHCONF"
    CONFIG_ACTION="✅ Setup SSH config file with alias github-opendreambox."
else
    CONFIG_ACTION="⚠️ The github-opendreambox configuration already exists in $SSHCONF"
fi

# 3. إضافة المفتاح إلى ssh-agent وتعيينه لـ Git
eval "$(ssh-agent -s)" >/dev/null
ssh-add "$KEY" >/dev/null 2>&1 || whiptail --title "Warning: ssh-add" --msgbox "⚠️ Warning: ssh-add failed or required a passphrase. Please check." 10 90

git config --global core.sshCommand "ssh -i $KEY"
GIT_ACTION="✅ Set private key ($KEY) as the global SSH command for Git."

# 4. عرض الرسالة الموحدة
whiptail --title "SSH Configuration Summary" \
--msgbox "==> SSH Setup completed.
\n* $KEY_ACTION
\n* $CONFIG_ACTION
\n* $GIT_ACTION" \
15 90

# ----------------------------------------------------------------------
# END: الكود الموحد
# ----------------------------------------------------------------------

echo "==> Displaying the public key in a text interface..."
TEMP_KEY_FILE=$(mktemp)
echo "**Copy the key below and add it immediately to GitHub → Settings → SSH and GPG keys**" > "$TEMP_KEY_FILE"
echo "" >> "$TEMP_KEY_FILE"
cat "$KEY.pub" >> "$TEMP_KEY_FILE"
whiptail --title "📋 IMPORTANT: Public SSH Key" \
--textbox "$TEMP_KEY_FILE" \
10 90 2 \
rm "$TEMP_KEY_FILE"
whiptail --title "Manual Step Confirmation" --yesno "Have you completed adding the Public Key to GitHub? (Must press 'Yes' to proceed)" 10 90
if [ $? -ne 0 ]; then
err "Operation cancelled. Please add the key and try again."
fi
whiptail --title "Install Packages" --msgbox "==> Updating system and installing required build packages..." 10 90
sudo apt-get update
sudo apt-get upgrade -y
sudo apt-get install -y gawk wget git-core diffstat unzip texinfo gcc-multilib build-essential chrpath socat cpio python python3 python3-pip python3-pexpect xz-utils debianutils iputils-ping
echo "==> Selecting device via graphical interface (Whiptail)..."
ORDERED=("dm520" "dm820" "dm7080" "dm900" "dm920" "dreamone" "dreamtwo")
WHIPTAIL_OPTIONS=()
i=1
for m in "${ORDERED[@]}"; do
WHIPTAIL_OPTIONS+=("$i" "$m")
DEVICES[$i]="$m"
((i++))
done
CHOSEN_NUM=$(whiptail --title "Build Image - Select Box" \
--menu "" \
20 80 9 \
"${WHIPTAIL_OPTIONS[@]}" 3>&1 1>&2 2>&3)
if [ $? -ne 0 ]; then
err "Device selection was cancelled."
fi
CHOSEN="${DEVICES[$CHOSEN_NUM]}"
BRANCH="${MACHINE_BRANCH[$CHOSEN]}"
[ -z "$CHOSEN" ] && err "Invalid selection."
echo "==> You chose: $CHOSEN"
if [ -d "$DIR/.git" ]; then
echo "==> Folder $DIR exists. Updating repository to branch: $BRANCH..."
cd "$DIR"
git remote set-url origin "$REPO_ALIAS"
git fetch origin
git checkout "$BRANCH" || git checkout -b "$BRANCH" origin/"$BRANCH"
else
echo "==> Cloning branch: $BRANCH into $DIR..."
git clone -b "$BRANCH" "$REPO_ALIAS" "$DIR" || err "Git clone failed. (SSH Error: Ensure you added the public key to GitHub before this step)"
cd "$DIR"
fi
echo "==> Running make update..."
make update
echo "==> Creating local-ext.conf in $DIR/conf for feed settings..."
cat << EOF > conf/local-ext.conf
DISTRO_FEED_URI = "http://dreamboxupdate.com/opendreambox/2.5/unstable/r0/\${MACHINE}/"
IMAGE_INSTALL_append = " opendreambox-archive-keyring"
EOF
echo "==> Selecting build target via graphical interface (Whiptail)..."
BUILD_OPTIONS=$(whiptail --title "Build Target Selection" \
--menu "Select what you want to build for: $CHOSEN" \
10 70 3 \
"1" "Image" \
"2" "Feed" 3>&1 1>&2 2>&3)
if [ $? -ne 0 ]; then
err "Build target selection was cancelled."
fi
case "$BUILD_OPTIONS" in
1)
TARGET="image"
DESCRIPTION="Image only"
;;
2)
TARGET="feed"
DESCRIPTION="Feed only"
;;
*)
err "Invalid build target selection. Script expects 1 or 2."
;;
esac
echo "==> Starting build ($DESCRIPTION) for: $CHOSEN..."
make MACHINE="$CHOSEN" $TARGET || err "Build for $CHOSEN failed. Check the console for errors."
whiptail --title "✅ Success" --msgbox "✅ Build ($DESCRIPTION) for $CHOSEN finished successfully." 15 100